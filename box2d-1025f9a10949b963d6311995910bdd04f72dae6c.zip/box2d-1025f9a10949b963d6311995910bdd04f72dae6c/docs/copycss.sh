#!/usr/bin/env bash
cp *.css ../build/docs/html/
